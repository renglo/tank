#!/bin/bash
export AWS_PROFILE=woppi
export AWS_DEFAULT_REGION=us-east-1
flask run
