WL_NAME='Woppi'


TANK_BASE_URL = 'https://apidev.woppi.ai'
TANK_FE_BASE_URL = 'https://apidev.woppi.ai'
TANK_DOC_BASE_URL = 'https://apidev.woppi.ai'
TANK_AWS_REGION = 'us-east-1'

#Crontab/Cronjob
TANK_API_GATEWAY_ARN = ''
TANK_ROLE_ARN = 'arn:aws:iam::430118822481:role/woppi_tt_role'
TANK_ENV = 'woppi_prod_0305a'


# DynamoDB
DYNAMODB_ENTITY_TABLE = 'woppi_entities'
DYNAMODB_BLUEPRINT_TABLE = 'woppi_blueprints'
DYNAMODB_RINGDATA_TABLE = 'woppi_data'
DYNAMODB_REL_TABLE = 'woppi_rel'
DYNAMODB_CHAT_TABLE = 'woppi_chat'


CSRF_SESSION_KEY = 'f80abc8171ca8774ab3f146047027254'
SECRET_KEY = 'fe552ef97204651f6c7c42a35fc1a8bc'


# flask_cognito
COGNITO_REGION = 'us-east-1'
COGNITO_USERPOOL_ID = 'us-east-1_7UDa6G9zc'
COGNITO_APP_CLIENT_ID = 'iairg3gdibtc83b8c0rf4e0p4'
COGNITO_CHECK_TOKEN_EXPIRATION = True  # Optional, default is True


#UI
PREVIEW_LAYER = 2

#-----------

S3_BUCKET_NAME = 'woppi-48396090'

#---------

#OPEN AI
OPENAI_API_KEY='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'


#WEB SOCKET
WEBSOCKET_CONNECTIONS='https://65ts1zrz49.execute-api.us-east-1.amazonaws.com/dev'